import Link from 'next/link';
import type { ReactNode } from 'react';

import { ArrowUpRight } from 'lucide-react';

import { cn } from '@/lib/utils';

import type { CommerceProduct } from '../../contracts/customerDashboardTypes';

import { JourneyProductCollage } from './JourneyProductCollage';

type JourneyCardTone = 'slate' | 'rose' | 'violet' | 'emerald' | 'amber';

type ProductJourneyCardProps = {
  code: string;
  title: string;
  count: number;
  href: string;
  icon: ReactNode;
  tone: JourneyCardTone;

  products: CommerceProduct[];

  supportingLabel?: string;
  emptyLabel?: string;
};

const toneStyles: Record<
  JourneyCardTone,
  {
    icon: string;
    metric: string;
    surface: string;
  }
> = {
  slate: {
    icon: 'bg-slate-500/10 text-slate-600 dark:text-slate-300',
    metric: 'text-slate-700 dark:text-slate-200',
    surface: 'from-slate-500/10 via-transparent to-transparent'
  },

  rose: {
    icon: 'bg-rose-500/10 text-rose-600 dark:text-rose-300',
    metric: 'text-rose-700 dark:text-rose-200',
    surface: 'from-rose-500/10 via-transparent to-transparent'
  },

  violet: {
    icon: 'bg-violet-500/10 text-violet-600 dark:text-violet-300',
    metric: 'text-violet-700 dark:text-violet-200',
    surface: 'from-violet-500/10 via-transparent to-transparent'
  },

  emerald: {
    icon: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-300',
    metric: 'text-emerald-700 dark:text-emerald-200',
    surface: 'from-emerald-500/10 via-transparent to-transparent'
  },

  amber: {
    icon: 'bg-amber-500/10 text-amber-700 dark:text-amber-300',
    metric: 'text-amber-700 dark:text-amber-200',
    surface: 'from-amber-500/10 via-transparent to-transparent'
  }
};

export function ProductJourneyCard({
  code,
  title,
  count,
  href,
  icon,
  tone,
  products,
  supportingLabel = 'Continue your journey',
  emptyLabel = 'Your products will appear here'
}: ProductJourneyCardProps) {
  const styles = toneStyles[tone];

  return (
    <Link
      data-rail-item
      href={href}
      aria-label={`Open ${title}`}
      className={cn(
        'group relative min-h-64 w-[82vw] max-w-72 shrink-0 snap-start overflow-hidden rounded-2xl border border-border/60 bg-card shadow-sm transition duration-300',
        'hover:-translate-y-1 hover:border-primary/25 hover:shadow-lg',
        'sm:w-72'
      )}>
      <div
        className={cn('pointer-events-none absolute inset-0 bg-gradient-to-br opacity-80', styles.surface)}
      />

      <div className="relative flex h-full flex-col p-3">
        <div className="flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2">
            <span
              className={cn(
                'grid size-9 shrink-0 place-items-center rounded-xl [&_svg]:size-4',
                styles.icon
              )}>
              {icon}
            </span>

            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">{title}</p>

              <p className="mt-0.5 text-[11px] font-medium text-muted-foreground">{code}</p>
            </div>
          </div>

          <span className="grid size-8 shrink-0 place-items-center rounded-xl border border-border/60 bg-background/90 text-muted-foreground shadow-sm transition group-hover:border-primary/25 group-hover:text-foreground">
            <ArrowUpRight className="size-4" />
          </span>
        </div>

        <JourneyProductCollage
          products={products}
          title={title}
          fillToFour
          className="mt-3 aspect-[16/10] w-full"
        />

        <div className="mt-auto flex items-end justify-between gap-3 pt-3">
          <div className="min-w-0">
            <p className={cn('text-2xl font-bold leading-none', styles.metric)}>{count}</p>

            <p className="mt-1 truncate text-xs text-muted-foreground">
              {count > 0 ? supportingLabel : emptyLabel}
            </p>
          </div>

          <span className="shrink-0 text-[11px] font-semibold text-muted-foreground transition group-hover:text-foreground">
            Open journey
          </span>
        </div>
      </div>
    </Link>
  );
}
