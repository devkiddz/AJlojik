export {
  recordProductView
} from './productActivityService';