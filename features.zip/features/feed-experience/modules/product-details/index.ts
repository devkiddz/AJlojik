export { ProductDetailsModule } from './ProductDetailsModule';
