'use client';

import Image from 'next/image';
import Link from 'next/link';

import {
  ArrowRight,
  BadgeCheck,
  Boxes,
  ChevronRight,
  ClipboardCheck,
  CircleDollarSign,
  Eye,
  Heart,
  PackageCheck,
  ShoppingBag,
  Sparkles,
  TrendingUp,
  TriangleAlert,
  Truck,
  WandSparkles,
  WalletCards
} from 'lucide-react';

import { useMemo, type ReactNode } from 'react';

import SignOutButton from '@/components/auth/SignOutButton';
import { useCart } from '@/features/cart';
import { useCatalog } from '@/features/catalog';
import { useWishlist } from '@/features/wishlist';
import { useWorkspace } from '@/features/workspace';
import { cn } from '@/lib/utils';

import type { ProductType } from '@/types/types';

export type ExpensePoint = {
  month: string;
  value: number;
};

type CommerceDashboardProps = {
  user: {
    name: string;
    email: string;
    image: string | null;
    tier: string;
    emailVerified: boolean;
  };
  persona: string;
  personalizationEnabled: boolean;
  recentProductIds: string[];
  expenseSeries: ExpensePoint[];
  totalSpent: number;
  orderCount: number;
  checkedOutCount: number;
  onDeliveryCount: number;
  shoppingListProductIds: string[];
};

const currencyFormatter = new Intl.NumberFormat('en-NG', {
  style: 'currency',
  currency: 'NGN',
  maximumFractionDigits: 0
});

const compactCurrencyFormatter = new Intl.NumberFormat('en-NG', {
  notation: 'compact',
  style: 'currency',
  currency: 'NGN',
  maximumFractionDigits: 1
});

function CommerceDashboardContent({
  user,
  persona,
  personalizationEnabled,
  recentProductIds,
  expenseSeries,
  totalSpent,
  orderCount,
  checkedOutCount,
  onDeliveryCount,
  shoppingListProductIds
}: CommerceDashboardProps) {
  const { products, loading: catalogLoading } = useCatalog();
  const { items: cartItems, totalQuantity, subtotal, loading: cartLoading } = useCart();
  const { productIds: wishlistProductIds, count: wishlistCount, loading: wishlistLoading } = useWishlist();
  const { activeWorkspace } = useWorkspace();

  const productById = useMemo(() => new Map(products.map(product => [product.id, product])), [products]);

  const recentProducts = useMemo(
    () =>
      recentProductIds
        .map(id => productById.get(id))
        .filter((product): product is ProductType => Boolean(product)),
    [productById, recentProductIds]
  );

  const wishlistProducts = useMemo(
    () =>
      wishlistProductIds
        .map(id => productById.get(id))
        .filter((product): product is ProductType => Boolean(product)),
    [productById, wishlistProductIds]
  );
  const shoppingListProducts = useMemo(
    () =>
      shoppingListProductIds
        .map(id => productById.get(id))
        .filter((product): product is ProductType => Boolean(product)),
    [productById, shoppingListProductIds]
  );

  const inventory = useMemo(() => {
    const variants = products.flatMap(product => product.variants);
    const totalUnits = variants.reduce((sum, variant) => sum + Math.max(variant.stockLeft, 0), 0);
    const lowStockVariants = variants.filter(
      variant => variant.stockLeft > 0 && variant.stockLeft <= 5
    ).length;
    const outOfStockVariants = variants.filter(variant => variant.stockLeft <= 0).length;
    const inventoryValue = variants.reduce(
      (sum, variant) => sum + Math.max(variant.stockLeft, 0) * Number(variant.price),
      0
    );

    return {
      totalUnits,
      lowStockVariants,
      outOfStockVariants,
      inventoryValue,
      variantCount: variants.length
    };
  }, [products]);

  const recommendations = useMemo(() => {
    const excludedIds = new Set([
      ...recentProductIds,
      ...wishlistProductIds,
      ...cartItems.map(item => item.productId)
    ]);
    const preferredCategories = new Set([
      ...recentProducts.map(product => product.category),
      ...wishlistProducts.map(product => product.category),
      ...cartItems.map(item => item.product.category),
      ...shoppingListProducts.map(product => product.category)
    ]);
    const shoppingListIds = new Set(shoppingListProductIds);

    return [...products]
      .filter(
        product => !excludedIds.has(product.id) && product.variants.some(variant => variant.stockLeft > 0)
      )
      .sort((first, second) => {
        const score = (product: ProductType) =>
          (preferredCategories.has(product.category) ? 6 : 0) +
          (shoppingListIds.has(product.id) ? 8 : 0) +
          (product.featured ? 3 : 0) +
          (product.isNew ? 2 : 0) +
          product.rating;

        return score(second) - score(first);
      })
      .slice(0, 6);
  }, [
    cartItems,
    products,
    recentProductIds,
    recentProducts,
    shoppingListProductIds,
    shoppingListProducts,
    wishlistProductIds,
    wishlistProducts
  ]);

  const maxExpense = Math.max(...expenseSeries.map(point => point.value), subtotal, 1);
  const firstName = user.name.split(' ')[0] || user.name;
  const dashboardLoading = catalogLoading || cartLoading || wishlistLoading;

  return (
    <main className="min-h-dvh bg-[radial-gradient(circle_at_top_right,hsl(var(--primary)/0.06),transparent_32%)] px-2.5 py-3 sm:px-4 lg:px-5">
      <div className="mx-auto max-w-[94rem] space-y-3">
        <header className="relative overflow-hidden rounded-2xl border border-border/60 bg-card/80 p-3 shadow-sm backdrop-blur-xl sm:p-4">
          <div className="pointer-events-none absolute -right-24 -top-28 size-80 rounded-full bg-primary/10 blur-3xl" />
          <div className="relative flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex min-w-0 items-center gap-3">
              <div className="relative grid size-10 shrink-0 place-items-center overflow-hidden rounded-xl bg-foreground text-sm font-bold text-background shadow-sm sm:size-12">
                {user.image ? (
                  <Image src={user.image} alt={user.name} fill sizes="64px" className="object-cover" />
                ) : (
                  user.name.charAt(0)
                )}
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-primary/70">
                    Personal commerce
                  </p>
                  {user.emailVerified ? <BadgeCheck className="size-4 text-emerald-500" /> : null}
                </div>
                <h1 className="mt-0.5 truncate text-xl font-bold tracking-tight sm:text-2xl">
                  Welcome back, {firstName}
                </h1>
                <p className="mt-1 truncate text-xs text-muted-foreground sm:text-sm">{user.email}</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <StatusPill
                label={activeWorkspace?.name ?? 'Workspace'}
                value={activeWorkspace?.mode ?? 'LIVE'}
              />
              <StatusPill label="Experience" value={persona.replaceAll('-', ' ')} />
              <SignOutButton />
            </div>
          </div>
        </header>

        <MobileCommerceDashboard
          inventory={inventory}
          recentProducts={recentProducts}
          wishlistProducts={wishlistProducts}
          cartProducts={cartItems.map(item => item.product)}
          recommendations={recommendations}
          shoppingListProducts={shoppingListProducts}
          wishlistCount={wishlistCount}
          cartCount={totalQuantity}
          checkedOutCount={checkedOutCount}
          onDeliveryCount={onDeliveryCount}
          totalSpent={totalSpent}
          orderCount={orderCount}
        />

        <div className="hidden space-y-3 sm:!block">
          <DesktopCommerceAnalytics
            inventory={inventory}
            expenseSeries={expenseSeries}
            maxExpense={maxExpense}
            subtotal={subtotal}
            totalSpent={totalSpent}
            orderCount={orderCount}
            wishlistCount={wishlistCount}
            cartCount={totalQuantity}
          />
          <section
            aria-label="Recent account activity"
            className="overflow-hidden rounded-2xl border border-border/60 bg-[linear-gradient(145deg,hsl(var(--card)/0.92),hsl(var(--muted)/0.34))] p-3 shadow-sm sm:p-4">
            <div className="mb-3 flex flex-col gap-2 px-1 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-primary/70">
                  Customer journey
                </p>
                <h2 className="mt-0.5 text-base font-bold tracking-tight">Your latest commerce signals</h2>
              </div>
              <div className="flex snap-x snap-mandatory gap-2 overflow-x-auto pb-1 scrollbar-hide sm:flex-wrap sm:overflow-visible sm:pb-0">
                <RelationshipPill label="Viewed" value={recentProducts.length} />
                <RelationshipPill label="In cart" value={totalQuantity} />
                <RelationshipPill label="Saved" value={wishlistCount} />
              </div>
            </div>

            <div className="flex snap-x snap-mandatory items-stretch gap-3 overflow-x-auto overscroll-x-contain pb-1.5 pr-4 scrollbar-hide">
              <article className="w-[84vw] max-w-xl shrink-0 snap-start rounded-2xl border border-border/60 bg-background/70 p-4 shadow-sm backdrop-blur sm:w-[66vw] xl:w-[38rem] xl:max-w-none">
                <SectionHeading
                  eyebrow="Recent activity"
                  title="Shopping activity"
                  description="Completed order spend with your current cart shown as planned spend."
                  actionHref="/orders"
                  actionLabel="View orders"
                />

                <div className="mt-4 flex min-h-40 snap-x snap-mandatory items-end gap-2 overflow-x-auto overscroll-x-contain pb-1.5 pr-4 scrollbar-hide sm:grid sm:min-h-44 sm:grid-cols-7 sm:overflow-visible sm:pb-0 sm:pr-0">
                  {expenseSeries.map(point => (
                    <ExpenseBar
                      key={point.month}
                      label={point.month}
                      value={point.value}
                      maxValue={maxExpense}
                    />
                  ))}
                  <ExpenseBar label="Cart" value={subtotal} maxValue={maxExpense} planned />
                </div>
              </article>

              <ProductSection
                eyebrow="Recent activity"
                title="Recently viewed"
                description="Pick up where your latest shopping sessions stopped."
                products={recentProducts}
                emptyMessage="Your recently viewed products will appear as you explore the store."
                compact
                journeyPeer
              />
            </div>
          </section>

          <section aria-label="Commerce overview" className="hidden">
            <MetricCard
              icon={<WalletCards />}
              label="Lifetime spend"
              value={currencyFormatter.format(totalSpent)}
              helper={`${orderCount} orders recorded`}
              tone="violet"
            />
            <MetricCard
              icon={<ShoppingBag />}
              label="Active cart"
              value={String(totalQuantity)}
              helper={currencyFormatter.format(subtotal)}
              tone="emerald"
            />
            <MetricCard
              icon={<Heart />}
              label="Saved products"
              value={String(wishlistCount)}
              helper="Synced wishlist"
              tone="rose"
            />
            <MetricCard
              icon={<Boxes />}
              label="Inventory units"
              value={inventory.totalUnits.toLocaleString()}
              helper={`${inventory.variantCount} product options`}
              tone="amber"
            />
          </section>

          <section className="hidden">
            <article className="rounded-[2rem] border border-border/60 bg-card/75 p-5 shadow-lg sm:p-6">
              <SectionHeading
                eyebrow="Store health"
                title="Inventory tracker"
                description="Live availability across catalog options."
              />

              <div className="mt-4 flex items-center justify-between sm:hidden">
                <p className="text-[10px] font-medium text-muted-foreground">
                  Swipe cards to inspect stock health
                </p>
                <span className="rounded-full border border-border/60 bg-background/70 px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider">
                  Slide →
                </span>
              </div>

              <div
                aria-label="Inventory metrics"
                className="mt-3 flex snap-x snap-mandatory gap-3 overflow-x-auto overscroll-x-contain pb-3 pr-8 scrollbar-hide sm:mt-6">
                <InventoryRow
                  icon={<PackageCheck />}
                  label="Available units"
                  value={inventory.totalUnits.toLocaleString()}
                  tone="emerald"
                />
                <InventoryRow
                  icon={<TriangleAlert />}
                  label="Low-stock options"
                  value={String(inventory.lowStockVariants)}
                  tone="amber"
                />
                <InventoryRow
                  icon={<Boxes />}
                  label="Out-of-stock options"
                  value={String(inventory.outOfStockVariants)}
                  tone="rose"
                />
                <InventoryRow
                  icon={<CircleDollarSign />}
                  label="Catalog stock value"
                  value={compactCurrencyFormatter.format(inventory.inventoryValue)}
                  tone="violet"
                />
              </div>

              <div className="mt-5 rounded-2xl bg-muted/60 p-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Availability health</span>
                  <span className="font-bold">
                    {inventory.variantCount
                      ? Math.round(
                          ((inventory.variantCount - inventory.outOfStockVariants) / inventory.variantCount) *
                            100
                        )
                      : 0}
                    %
                  </span>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-background">
                  <div
                    className="h-full rounded-full bg-emerald-500 transition-all"
                    style={{
                      width: `${inventory.variantCount ? ((inventory.variantCount - inventory.outOfStockVariants) / inventory.variantCount) * 100 : 0}%`
                    }}
                  />
                </div>
              </div>
            </article>
          </section>

          <section
            aria-label="Shopping workspace"
            className="rounded-2xl border border-border/60 bg-card/50 p-3 shadow-sm sm:p-4">
            <div className="mb-4 flex flex-col gap-3 px-2 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-primary/70">
                  Shopping workspace
                </p>
                <h2 className="mt-0.5 text-base font-bold tracking-tight">Move products toward checkout</h2>
                <p className="mt-1 text-xs text-muted-foreground">
                  Your cart and wishlist stay connected, so saved ideas can become active purchases.
                </p>
              </div>
              <Link
                href="/store"
                className="inline-flex shrink-0 items-center gap-1 text-xs font-semibold text-primary">
                Discover products <ArrowRight className="size-3.5" />
              </Link>
            </div>

            <div className="flex snap-x snap-mandatory gap-3 overflow-x-auto overscroll-x-contain pb-1.5 pr-4 scrollbar-hide">
              <ShoppingListCard
                icon={<ShoppingBag className="size-4" />}
                eyebrow="Ready when you are"
                title="Cart products"
                count={totalQuantity}
                products={cartItems.map(item => item.product)}
                href="/cart"
                emptyMessage="Your cart is ready for something exceptional."
              />
              <ShoppingListCard
                icon={<Heart className="size-4" />}
                eyebrow="Your collection"
                title="Wishlist products"
                count={wishlistCount}
                products={wishlistProducts}
                href="/wishlist"
                emptyMessage="Save products to build your personal collection."
              />
            </div>
          </section>

          <ProductSection
            eyebrow="Curated for you"
            title="Recommended next"
            description={
              personalizationEnabled
                ? 'Ranked from your recent categories, saved products, and cart activity.'
                : 'Popular premium products from across AJ Logik.'
            }
            products={recommendations}
            emptyMessage="Recommendations will appear when more catalog products are available."
            featured
          />

          {dashboardLoading ? (
            <p className="text-center text-xs text-muted-foreground">Refreshing your commerce workspace…</p>
          ) : null}
        </div>
      </div>
    </main>
  );
}

export default function CommerceDashboard(props: CommerceDashboardProps) {
  return <CommerceDashboardContent {...props} />;
}

type MobileInventory = {
  totalUnits: number;
  lowStockVariants: number;
  outOfStockVariants: number;
  inventoryValue: number;
  variantCount: number;
};

function DesktopCommerceAnalytics({
  inventory,
  expenseSeries,
  maxExpense,
  subtotal,
  totalSpent,
  orderCount,
  wishlistCount,
  cartCount
}: {
  inventory: MobileInventory;
  expenseSeries: ExpensePoint[];
  maxExpense: number;
  subtotal: number;
  totalSpent: number;
  orderCount: number;
  wishlistCount: number;
  cartCount: number;
}) {
  const availableVariants = Math.max(
    inventory.variantCount - inventory.lowStockVariants - inventory.outOfStockVariants,
    0
  );
  const stockHealth = inventory.variantCount
    ? Math.round(((inventory.variantCount - inventory.outOfStockVariants) / inventory.variantCount) * 100)
    : 0;
  const segment = (value: number) => (inventory.variantCount ? (value / inventory.variantCount) * 100 : 0);

  return (
    <section
      aria-label="Commerce command center"
      className="overflow-hidden rounded-2xl border border-border/60 bg-[linear-gradient(135deg,hsl(var(--card)/0.96),hsl(var(--muted)/0.32))] p-4 shadow-sm lg:p-5">
      <div className="mb-4 flex items-end justify-between gap-4">
        <div>
          <p className="text-[10px] font-black uppercase tracking-[0.24em] text-primary">
            Commerce command center
          </p>
          <h2 className="mt-1 text-xl font-bold tracking-tight lg:text-2xl">
            Your inventory, spend and shopping pulse
          </h2>
          <p className="mt-2 max-w-2xl text-xs text-muted-foreground lg:text-sm">
            A live view of what is available, what needs attention, and how your commerce activity is moving.
          </p>
        </div>
        <Link
          href="/store"
          className="hidden items-center gap-1.5 rounded-full bg-foreground px-4 py-2 text-[11px] font-bold text-background transition hover:opacity-90 lg:inline-flex">
          Open store <ArrowRight className="size-4" />
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-12">
        <article className="col-span-2 overflow-hidden rounded-2xl bg-[#07172b] p-4 text-white shadow-sm lg:col-span-7 lg:min-h-[18rem] lg:p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[.2em] text-emerald-300">
                Inventory health
              </p>
              <h3 className="mt-1 text-lg font-bold lg:text-xl">Stock distribution</h3>
            </div>
            <span className="rounded-full border border-white/15 bg-white/10 px-2.5 py-1 text-[9px] font-bold">
              {inventory.variantCount} options
            </span>
          </div>
          <div className="mt-5 grid items-center gap-4 md:grid-cols-[10rem_1fr]">
            <div
              className="relative mx-auto grid size-36 place-items-center rounded-full shadow-[0_0_40px_rgba(16,185,129,.14)] lg:size-40"
              style={{
                background: `conic-gradient(#10b981 0 ${segment(availableVariants)}%, #f59e0b ${segment(availableVariants)}% ${segment(availableVariants + inventory.lowStockVariants)}%, #f43f5e 0)`
              }}>
              <div className="grid size-28 place-items-center rounded-full bg-[#07172b] text-center lg:size-32">
                <div>
                  <p className="text-3xl font-bold lg:text-4xl">{stockHealth}%</p>
                  <p className="mt-1 text-[10px] uppercase tracking-[.18em] text-white/50">available</p>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <StockLegend
                color="bg-emerald-400"
                label="Healthy options"
                value={availableVariants}
                total={inventory.variantCount}
              />
              <StockLegend
                color="bg-amber-400"
                label="Low stock"
                value={inventory.lowStockVariants}
                total={inventory.variantCount}
              />
              <StockLegend
                color="bg-rose-400"
                label="Unavailable"
                value={inventory.outOfStockVariants}
                total={inventory.variantCount}
              />
              <div className="mt-3 rounded-xl border border-white/10 bg-white/[.07] p-3">
                <p className="text-[10px] text-white/50">Total units in circulation</p>
                <p className="mt-0.5 text-xl font-bold lg:text-2xl">
                  {inventory.totalUnits.toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        </article>

        <article className="col-span-2 rounded-2xl border border-border/60 bg-background/75 p-4 shadow-sm lg:col-span-5 lg:min-h-[18rem] lg:p-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[.2em] text-violet-500">Budget rhythm</p>
              <h3 className="mt-1 text-lg font-bold lg:text-xl">Spend activity</h3>
            </div>
            <span className="grid size-9 place-items-center rounded-xl bg-violet-500/10 text-violet-500">
              <WalletCards className="size-4" />
            </span>
          </div>
          <div className="mt-5 flex h-40 items-end gap-2 lg:h-44">
            {expenseSeries.map(point => (
              <DesktopBudgetBar
                key={point.month}
                label={point.month}
                value={point.value}
                maxValue={maxExpense}
              />
            ))}
            <DesktopBudgetBar label="Cart" value={subtotal} maxValue={maxExpense} planned />
          </div>
          <div className="mt-4 flex items-center justify-between border-t border-border/60 pt-3">
            <div>
              <p className="text-[10px] text-muted-foreground">Lifetime recorded</p>
              <p className="mt-0.5 text-base font-bold lg:text-lg">
                {compactCurrencyFormatter.format(totalSpent)}
              </p>
            </div>
            <p className="text-right text-[10px] text-muted-foreground">
              {orderCount}
              <br />
              completed orders
            </p>
          </div>
        </article>

        <AnalyticsTile
          className="rounded-xl lg:col-span-3"
          icon={<CircleDollarSign />}
          label="Inventory value"
          value={compactCurrencyFormatter.format(inventory.inventoryValue)}
          helper="Current catalog estimate"
          tone="violet"
        />
        <AnalyticsTile
          className="rounded-xl lg:col-span-3"
          icon={<ShoppingBag />}
          label="Active cart"
          value={String(cartCount)}
          helper={currencyFormatter.format(subtotal)}
          tone="emerald"
        />
        <AnalyticsTile
          className="rounded-xl lg:col-span-3"
          icon={<Heart />}
          label="Saved products"
          value={String(wishlistCount)}
          helper="Synced to your wishlist"
          tone="rose"
        />
        <AnalyticsTile
          className="rounded-xl lg:col-span-3"
          icon={<PackageCheck />}
          label="Orders completed"
          value={String(orderCount)}
          helper="Your commerce history"
          tone="amber"
        />
      </div>
    </section>
  );
}

function StockLegend({
  color,
  label,
  value,
  total
}: {
  color: string;
  label: string;
  value: number;
  total: number;
}) {
  return (
    <div className="rounded-xl bg-white/[.06] p-2.5">
      <div className="flex items-center gap-2.5">
        <span className={cn('size-2.5 rounded-full', color)} />
        <span className="flex-1 text-xs text-white/65">{label}</span>
        <strong className="text-sm">{value}</strong>
      </div>
      <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
        <div
          className={cn('h-full rounded-full', color)}
          style={{ width: `${total ? (value / total) * 100 : 0}%` }}
        />
      </div>
    </div>
  );
}

function DesktopBudgetBar({
  label,
  value,
  maxValue,
  planned = false
}: {
  label: string;
  value: number;
  maxValue: number;
  planned?: boolean;
}) {
  const height = value > 0 ? Math.max((value / maxValue) * 100, 7) : 3;
  return (
    <div className="group flex h-full min-w-0 flex-1 flex-col justify-end text-center">
      <span className="mb-1.5 hidden truncate text-[8px] font-bold group-hover:block xl:block">
        {compactCurrencyFormatter.format(value)}
      </span>
      <div className="relative flex min-h-0 flex-1 items-end overflow-hidden rounded-lg bg-muted/70 p-1">
        <div
          className={cn(
            'w-full rounded-full transition-all duration-500 group-hover:brightness-110',
            planned ? 'bg-primary' : 'bg-foreground/80'
          )}
          style={{ height: `${height}%` }}
        />
      </div>
      <span className={cn('mt-1.5 text-[8px]', planned ? 'font-bold text-primary' : 'text-muted-foreground')}>
        {label}
      </span>
    </div>
  );
}

function AnalyticsTile({
  className,
  icon,
  label,
  value,
  helper,
  tone
}: {
  className?: string;
  icon: ReactNode;
  label: string;
  value: string;
  helper: string;
  tone: Tone;
}) {
  return (
    <article
      className={cn(
        'group col-span-1 min-h-32 border border-border/60 bg-card/80 p-3 shadow-sm transition duration-300 hover:bg-card lg:min-h-36 lg:p-4',
        className
      )}>
      <div className={cn('grid size-9 place-items-center rounded-xl [&_svg]:size-4', toneStyles[tone])}>
        {icon}
      </div>
      <p className="mt-4 text-[9px] font-semibold uppercase tracking-[.14em] text-muted-foreground">
        {label}
      </p>
      <p className="mt-1 truncate text-xl font-bold tracking-tight lg:text-2xl">{value}</p>
      <p className="mt-1 truncate text-[10px] text-muted-foreground">{helper}</p>
    </article>
  );
}

function MobileCommerceDashboard({
  inventory,
  recentProducts,
  wishlistProducts,
  cartProducts,
  recommendations,
  shoppingListProducts,
  wishlistCount,
  cartCount,
  checkedOutCount,
  onDeliveryCount,
  totalSpent,
  orderCount
}: {
  inventory: MobileInventory;
  recentProducts: ProductType[];
  wishlistProducts: ProductType[];
  cartProducts: ProductType[];
  recommendations: ProductType[];
  shoppingListProducts: ProductType[];
  wishlistCount: number;
  cartCount: number;
  checkedOutCount: number;
  onDeliveryCount: number;
  totalSpent: number;
  orderCount: number;
}) {
  const smartPicks = recommendations.filter(product => product.featured || product.isNew).slice(0, 4);
  const stockHealth = inventory.variantCount
    ? Math.round(((inventory.variantCount - inventory.outOfStockVariants) / inventory.variantCount) * 100)
    : 0;
  return (
    <div className="block space-y-3 sm:!hidden">
      <section className="overflow-hidden rounded-2xl border border-border/60 bg-card/80 p-3 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[9px] font-bold uppercase tracking-[.2em] text-primary">Commerce pulse</p>
            <h2 className="mt-0.5 text-base font-bold">Inventory & activity</h2>
          </div>
          <Link
            href="/orders"
            className="grid size-9 place-items-center rounded-full border border-border/60">
            <ChevronRight className="size-4" />
          </Link>
        </div>
        <div className="mt-4 grid grid-cols-4 gap-2">
          <MobileRing label="Stock" value={`${stockHealth}%`} progress={stockHealth} tone="emerald" />
          <MobileRing
            label="Units"
            value={compactNumber(inventory.totalUnits)}
            progress={Math.min(inventory.totalUnits, 100)}
            tone="violet"
          />
          <MobileRing
            label="Orders"
            value={String(orderCount)}
            progress={Math.min(orderCount * 12, 100)}
            tone="amber"
          />
          <MobileRing
            label="Alerts"
            value={String(inventory.lowStockVariants + inventory.outOfStockVariants)}
            progress={Math.min((inventory.lowStockVariants + inventory.outOfStockVariants) * 14, 100)}
            tone="rose"
          />
        </div>
        <div className="mt-4 rounded-xl bg-background/70 p-2.5">
          <div className="flex h-16 items-end gap-2">
            {[
              inventory.totalUnits,
              Math.max(inventory.variantCount - inventory.outOfStockVariants, 0),
              inventory.lowStockVariants,
              inventory.outOfStockVariants
            ].map((value, index) => {
              const maximum = Math.max(inventory.totalUnits, inventory.variantCount, 1);
              const labels = ['Units', 'Ready', 'Low', 'Out'];
              const colors = ['bg-violet-500', 'bg-emerald-500', 'bg-amber-500', 'bg-rose-500'];
              return (
                <div key={labels[index]} className="flex h-full flex-1 flex-col justify-end text-center">
                  <div className="flex flex-1 items-end overflow-hidden rounded-lg bg-muted/60 p-1">
                    <span
                      className={cn('w-full rounded-md', colors[index])}
                      style={{ height: `${Math.max((value / maximum) * 100, value ? 8 : 2)}%` }}
                    />
                  </div>
                  <span className="mt-1.5 text-[8px] font-bold text-muted-foreground">{labels[index]}</span>
                </div>
              );
            })}
          </div>
        </div>
        <div className="mt-4 divide-y divide-border/50 rounded-xl bg-muted/45 px-2.5">
          <MobileSignal
            icon={<WalletCards />}
            label="Lifetime commerce"
            helper={`${orderCount} completed activities`}
            value={compactCurrencyFormatter.format(totalSpent)}
          />
          <MobileSignal
            icon={<Boxes />}
            label="Catalog stock value"
            helper={`${inventory.variantCount} active options`}
            value={compactCurrencyFormatter.format(inventory.inventoryValue)}
          />
          <MobileSignal
            icon={<TriangleAlert />}
            label="Inventory attention"
            helper="Low and unavailable options"
            value={String(inventory.lowStockVariants + inventory.outOfStockVariants)}
            alert
          />
        </div>
      </section>

      <MobileBlock title="Commerce journey" subtitle="Swipe through each stage of your shopping flow">
        <div className="flex snap-x snap-mandatory gap-3 overflow-x-auto pb-2 pr-6 scrollbar-hide">
          <MobileStage
            icon={<Heart />}
            title="Wish listed"
            count={wishlistCount}
            products={wishlistProducts}
            href="/wishlist"
            tone="rose"
          />
          <MobileStage
            icon={<ShoppingBag />}
            title="Carted"
            count={cartCount}
            products={cartProducts}
            href="/cart"
            tone="emerald"
          />
          <MobileStage
            icon={<ClipboardCheck />}
            title="Checked out"
            count={checkedOutCount}
            products={[]}
            href="/orders"
            tone="violet"
          />
          <MobileStage
            icon={<Truck />}
            title="On delivery"
            count={onDeliveryCount}
            products={[]}
            href="/orders"
            tone="amber"
          />
        </div>
      </MobileBlock>

      <MobileBlock
        title="Discovery intelligence"
        subtitle="Your activity, recommendations, and smart selections">
        <div className="flex snap-x snap-mandatory gap-3 overflow-x-auto pb-2 pr-5 scrollbar-hide">
          <MobileProductGroup
            icon={<Heart />}
            eyebrow="Your playlists"
            title="Shopping lists"
            products={shoppingListProducts}
            href="/settings"
          />
          <MobileProductGroup
            icon={<Eye />}
            eyebrow="Continue"
            title="Recently viewed"
            products={recentProducts}
            href="/store"
          />
          <MobileProductGroup
            icon={<Sparkles />}
            eyebrow="For you"
            title="Recommended"
            products={recommendations}
            href="/store"
          />
          <MobileProductGroup
            icon={<WandSparkles />}
            eyebrow="AJ intelligence"
            title="Smart picks"
            products={smartPicks.length ? smartPicks : recommendations}
            href="/ai"
          />
        </div>
      </MobileBlock>

      <section className="overflow-hidden rounded-2xl border border-border/60 bg-[#07172b] p-4 text-white shadow-sm">
        <p className="text-[9px] font-black uppercase tracking-[.2em] text-amber-300">Store experience</p>
        <div className="mt-2 flex items-end justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold">Keep discovering</h2>
            <p className="mt-1 text-xs leading-5 text-white/60">
              Fresh products and moments chosen around your activity.
            </p>
          </div>
          <Link
            href="/store"
            className="grid size-10 shrink-0 place-items-center rounded-full bg-white text-[#07172b]">
            <ArrowRight className="size-4" />
          </Link>
        </div>
        <div className="mt-4 flex snap-x gap-2.5 overflow-x-auto pb-1 scrollbar-hide">
          {recommendations.slice(0, 4).map(product => (
            <MobileProductTile key={product.id} product={product} dark />
          ))}
        </div>
      </section>
    </div>
  );
}

function MobileBlock({
  title,
  subtitle,
  children
}: {
  title: string;
  subtitle: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-border/60 bg-card/75 p-3 shadow-sm">
      <div className="mb-3">
        <h2 className="text-base font-bold">{title}</h2>
        <p className="mt-1 text-[10px] leading-4 text-muted-foreground">{subtitle}</p>
      </div>
      {children}
    </section>
  );
}
function MobileRing({
  label,
  value,
  progress,
  tone
}: {
  label: string;
  value: string;
  progress: number;
  tone: Tone;
}) {
  const color =
    tone === 'emerald' ? '#10b981' : tone === 'violet' ? '#8b5cf6' : tone === 'amber' ? '#f59e0b' : '#f43f5e';
  return (
    <div className="min-w-0 text-center">
      <div
        className="relative mx-auto grid size-11 place-items-center rounded-full"
        style={{ background: `conic-gradient(${color} ${Math.max(progress, 4)}%, hsl(var(--muted)) 0)` }}>
        <div className="grid size-8 place-items-center rounded-full bg-card text-[10px] font-bold">
          {value}
        </div>
      </div>
      <p className="mt-1.5 truncate text-[8px] font-semibold text-muted-foreground">{label}</p>
    </div>
  );
}
function MobileSignal({
  icon,
  label,
  helper,
  value,
  alert = false
}: {
  icon: ReactNode;
  label: string;
  helper: string;
  value: string;
  alert?: boolean;
}) {
  return (
    <div className="flex items-center gap-2.5 py-2.5">
      <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-background text-primary [&_svg]:size-3.5">
        {icon}
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-xs font-bold">{label}</p>
        <p className="mt-0.5 truncate text-[9px] text-muted-foreground">{helper}</p>
      </div>
      <span className={cn('shrink-0 text-xs font-black', alert && 'text-rose-500')}>{value}</span>
    </div>
  );
}
function MobileStage({
  icon,
  title,
  count,
  products,
  href,
  tone
}: {
  icon: ReactNode;
  title: string;
  count: number;
  products: ProductType[];
  href: string;
  tone: Tone;
}) {
  return (
    <Link
      href={href}
      className="w-[64vw] max-w-56 shrink-0 snap-start rounded-2xl border border-border/55 bg-background/70 p-3">
      <div className="flex items-center justify-between">
        <span className={cn('grid size-8 place-items-center rounded-xl [&_svg]:size-3.5', toneStyles[tone])}>
          {icon}
        </span>
        <span className="text-xl font-bold">{count}</span>
      </div>
      <h3 className="mt-3 text-sm font-bold">{title}</h3>
      <p className="mt-1 text-[9px] text-muted-foreground">Products at this stage</p>
      <div className="mt-3 flex -space-x-2">
        {products.slice(0, 4).map(product => {
          const variant = product.variants[0];
          return (
            <span
              key={product.id}
              className="relative size-8 overflow-hidden rounded-full border-2 border-background bg-muted">
              {variant ? (
                <Image src={variant.image} alt="" fill sizes="36px" className="object-cover" />
              ) : null}
            </span>
          );
        })}
        {!products.length ? (
          <span className="inline-flex h-8 items-center rounded-full bg-muted px-2.5 text-[9px] font-semibold">
            View activity
          </span>
        ) : null}
      </div>
    </Link>
  );
}
function MobileProductGroup({
  icon,
  eyebrow,
  title,
  products,
  href
}: {
  icon: ReactNode;
  eyebrow: string;
  title: string;
  products: ProductType[];
  href: string;
}) {
  return (
    <article className="w-[76vw] shrink-0 snap-start overflow-hidden rounded-2xl bg-muted/45 p-3">
      <div className="flex items-center gap-2.5">
        <span className="grid size-8 shrink-0 place-items-center rounded-xl bg-background text-primary [&_svg]:size-3.5">
          {icon}
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[8px] font-bold uppercase tracking-[.16em] text-muted-foreground">{eyebrow}</p>
          <h3 className="mt-0.5 text-sm font-black">{title}</h3>
        </div>
        <Link href={href} className="grid size-8 place-items-center rounded-full bg-background">
          <ChevronRight className="size-4" />
        </Link>
      </div>
      <div className="mt-3 flex snap-x gap-2 overflow-x-auto scrollbar-hide">
        {products.slice(0, 4).map(product => (
          <MobileProductTile key={product.id} product={product} />
        ))}
        {!products.length ? (
          <p className="py-4 text-[10px] text-muted-foreground">This section grows as you shop.</p>
        ) : null}
      </div>
    </article>
  );
}
function MobileProductTile({ product, dark = false }: { product: ProductType; dark?: boolean }) {
  const variant = product.variants.find(item => item.stockLeft > 0) ?? product.variants[0];
  return (
    <Link href={`/products/${product.slug}`} className="w-24 shrink-0 snap-start">
      <div className="relative aspect-square overflow-hidden rounded-xl bg-muted">
        {variant ? (
          <Image src={variant.image} alt={product.name} fill sizes="112px" className="object-cover" />
        ) : null}
      </div>
      <p className={cn('mt-2 truncate text-[10px] font-bold', dark && 'text-white')}>{product.name}</p>
      <p className={cn('mt-0.5 text-[9px]', dark ? 'text-white/55' : 'text-muted-foreground')}>
        {variant ? compactCurrencyFormatter.format(variant.price) : 'Unavailable'}
      </p>
    </Link>
  );
}
function compactNumber(value: number) {
  return new Intl.NumberFormat('en-NG', { notation: 'compact', maximumFractionDigits: 1 }).format(value);
}

function MetricCard({
  icon,
  label,
  value,
  helper,
  tone
}: {
  icon: ReactNode;
  label: string;
  value: string;
  helper: string;
  tone: Tone;
}) {
  return (
    <article className="group w-[72vw] max-w-64 shrink-0 snap-start rounded-3xl border border-border/60 bg-card/75 p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg sm:w-auto sm:max-w-none sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className={cn('grid size-8 place-items-center rounded-xl [&_svg]:size-3.5', toneStyles[tone])}>
          {icon}
        </div>
        <TrendingUp className="size-4 text-emerald-500" />
      </div>
      <p className="mt-5 text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 truncate text-2xl font-bold tracking-tight">{value}</p>
      <p className="mt-2 truncate text-[10px] text-muted-foreground">{helper}</p>
    </article>
  );
}

function ExpenseBar({
  label,
  value,
  maxValue,
  planned = false
}: {
  label: string;
  value: number;
  maxValue: number;
  planned?: boolean;
}) {
  const height = value > 0 ? Math.max((value / maxValue) * 100, 8) : 3;

  return (
    <div className="group flex h-full w-11 shrink-0 snap-start flex-col justify-end text-center sm:w-auto sm:min-w-0">
      <span className="mb-2 truncate text-[9px] font-semibold opacity-0 transition group-hover:opacity-100 sm:text-[10px]">
        {compactCurrencyFormatter.format(value)}
      </span>
      <div className="relative mx-auto flex h-48 w-full max-w-10 items-end overflow-hidden rounded-xl bg-muted/60 p-1 sm:h-52">
        <div
          className={cn(
            'w-full rounded-lg transition-all duration-500 group-hover:brightness-110',
            planned ? 'bg-primary' : 'bg-foreground/80'
          )}
          style={{ height: `${height}%` }}
        />
      </div>
      <span
        className={cn(
          'mt-2 truncate text-[9px] sm:text-[10px]',
          planned ? 'font-bold text-primary' : 'text-muted-foreground'
        )}>
        {label}
      </span>
    </div>
  );
}

function ProductSection({
  eyebrow,
  title,
  description,
  products,
  emptyMessage,
  featured = false,
  compact = false,
  journeyPeer = false
}: {
  eyebrow: string;
  title: string;
  description: string;
  products: ProductType[];
  emptyMessage: string;
  featured?: boolean;
  compact?: boolean;
  journeyPeer?: boolean;
}) {
  return (
    <section
      className={cn(
        'rounded-2xl border border-border/60 bg-card/60 p-4 shadow-sm',
        journeyPeer && 'w-[84vw] max-w-xl shrink-0 snap-start sm:w-[66vw] xl:w-[38rem] xl:max-w-none'
      )}>
      <SectionHeading
        eyebrow={eyebrow}
        title={title}
        description={description}
        actionHref="/store"
        actionLabel="Explore store"
      />
      {products.length ? (
        <div className="mt-4 flex snap-x snap-mandatory gap-2.5 overflow-x-auto overscroll-x-contain pb-1.5 pr-4 scrollbar-hide">
          {products.slice(0, compact ? 3 : 6).map(product => (
            <div
              key={product.id}
              className={cn(
                'shrink-0 snap-start',
                compact ? 'w-28 sm:w-32' : featured ? 'w-32 sm:w-36 xl:w-40' : 'w-32 sm:w-36'
              )}>
              <DashboardProductCard product={product} />
            </div>
          ))}
        </div>
      ) : (
        <EmptyPanel message={emptyMessage} />
      )}
    </section>
  );
}

function DashboardProductCard({ product }: { product: ProductType }) {
  const variant = product.variants.find(item => item.stockLeft > 0) ?? product.variants[0];

  return (
    <Link
      href={`/products/${product.slug}`}
      className="group min-w-0 rounded-xl p-1.5 transition hover:bg-muted/70">
      <div className="relative aspect-square overflow-hidden rounded-xl bg-muted shadow-sm">
        {variant ? (
          <Image
            src={variant.image}
            alt={product.name}
            fill
            sizes="180px"
            className="object-cover transition duration-500 group-hover:scale-105"
          />
        ) : null}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent" />
        <span className="absolute bottom-2 left-2 rounded-full bg-white/90 px-2 py-1 text-[9px] font-bold text-black shadow-sm">
          {variant ? compactCurrencyFormatter.format(variant.price) : 'N/A'}
        </span>
        <span className="absolute bottom-2 right-2 grid size-7 translate-y-0.5 place-items-center rounded-full bg-primary text-primary-foreground opacity-90 shadow-sm transition duration-300 group-hover:translate-y-0 group-hover:opacity-100">
          <ArrowRight className="size-3.5" />
        </span>
      </div>
      <p className="mt-2 truncate text-xs font-semibold">{product.name}</p>
      <p className="mt-1 truncate text-[10px] capitalize text-muted-foreground">
        {product.category.replaceAll('-', ' ')}
      </p>
    </Link>
  );
}

function ShoppingListCard({
  icon,
  eyebrow,
  title,
  count,
  products,
  href,
  emptyMessage
}: {
  icon: ReactNode;
  eyebrow: string;
  title: string;
  count: number;
  products: ProductType[];
  href: string;
  emptyMessage: string;
}) {
  const uniqueProducts = Array.from(new Map(products.map(product => [product.id, product])).values()).slice(
    0,
    4
  );

  return (
    <article className="w-[78vw] max-w-sm shrink-0 snap-start rounded-2xl border border-border/60 bg-card/70 p-3 shadow-sm sm:w-96 sm:max-w-none sm:p-4 lg:w-[28rem]">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="grid size-9 place-items-center rounded-xl bg-primary/10 text-primary">{icon}</div>
          <div>
            <p className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              {eyebrow}
            </p>
            <h2 className="mt-0.5 text-base font-bold">{title}</h2>
          </div>
        </div>
        <span className="rounded-full bg-muted px-2.5 py-1 text-xs font-bold">{count}</span>
      </div>

      {uniqueProducts.length ? (
        <div className="mt-4 space-y-1.5">
          {uniqueProducts.map(product => {
            const variant = product.variants.find(item => item.stockLeft > 0) ?? product.variants[0];
            return (
              <Link
                key={product.id}
                href={`/products/${product.slug}`}
                className="group flex items-center gap-2.5 rounded-xl p-1.5 transition hover:bg-muted/60">
                <div className="relative size-10 shrink-0 overflow-hidden rounded-lg bg-muted">
                  {variant ? (
                    <Image
                      src={variant.image}
                      alt={product.name}
                      fill
                      sizes="48px"
                      className="object-cover"
                    />
                  ) : null}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-semibold">{product.name}</p>
                  <p className="mt-1 text-[10px] text-muted-foreground">
                    {variant ? currencyFormatter.format(variant.price) : 'Unavailable'}
                  </p>
                </div>
                <ChevronRight className="size-4 text-muted-foreground transition group-hover:translate-x-0.5" />
              </Link>
            );
          })}
        </div>
      ) : (
        <EmptyPanel message={emptyMessage} compact />
      )}

      <Link
        href={href}
        className="mt-3 flex items-center justify-center gap-1.5 rounded-full border border-border/70 px-3 py-2 text-[11px] font-semibold transition hover:bg-foreground hover:text-background">
        Open {title.toLowerCase()} <ArrowRight className="size-3.5" />
      </Link>
    </article>
  );
}

function SectionHeading({
  eyebrow,
  title,
  description,
  actionHref,
  actionLabel
}: {
  eyebrow: string;
  title: string;
  description: string;
  actionHref?: string;
  actionLabel?: string;
}) {
  return (
    <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-primary/70">{eyebrow}</p>
        <h2 className="mt-0.5 text-base font-bold tracking-tight sm:text-lg">{title}</h2>
        <p className="mt-1 max-w-2xl text-[11px] leading-4 text-muted-foreground">{description}</p>
      </div>
      {actionHref && actionLabel ? (
        <Link
          href={actionHref}
          className="inline-flex shrink-0 items-center gap-1 text-xs font-semibold text-primary">
          {actionLabel}
          <ArrowRight className="size-3.5" />
        </Link>
      ) : null}
    </div>
  );
}

function InventoryRow({
  icon,
  label,
  value,
  tone
}: {
  icon: ReactNode;
  label: string;
  value: string;
  tone: Tone;
}) {
  return (
    <div className="flex min-h-24 w-[78vw] max-w-72 shrink-0 snap-start flex-col justify-between rounded-2xl border border-border/50 bg-background/70 p-4 shadow-sm sm:min-h-0 sm:w-64 sm:max-w-none sm:flex-row sm:items-center sm:gap-3">
      <div className="flex items-center justify-between sm:contents">
        <div className={cn('grid size-10 place-items-center rounded-xl [&_svg]:size-4', toneStyles[tone])}>
          {icon}
        </div>
        <span className="text-lg font-bold sm:order-3 sm:text-sm">{value}</span>
      </div>
      <span className="mt-3 min-w-0 flex-1 truncate text-xs text-muted-foreground sm:mt-0">{label}</span>
    </div>
  );
}

function StatusPill({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-full border border-border/60 bg-background/65 px-2.5 py-1.5">
      <span className="text-[9px] text-muted-foreground">{label}</span>
      <span className="ml-2 text-[10px] font-bold uppercase">{value}</span>
    </div>
  );
}

function RelationshipPill({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex shrink-0 snap-start items-center gap-1.5 rounded-full border border-border/60 bg-background/65 px-2.5 py-1.5 text-[9px]">
      <span className="text-muted-foreground">{label}</span>
      <span className="grid min-w-5 place-items-center rounded-full bg-foreground px-1.5 py-0.5 font-bold text-background">
        {value}
      </span>
    </div>
  );
}

function EmptyPanel({ message, compact = false }: { message: string; compact?: boolean }) {
  return (
    <div
      className={cn(
        'mt-4 grid place-items-center rounded-xl border border-dashed border-border/70 bg-muted/30 px-4 text-center',
        compact ? 'min-h-20' : 'min-h-28'
      )}>
      <div>
        <Sparkles className="mx-auto size-5 text-muted-foreground" />
        <p className="mt-2 text-xs leading-5 text-muted-foreground">{message}</p>
      </div>
    </div>
  );
}

type Tone = 'violet' | 'emerald' | 'rose' | 'amber';
const toneStyles: Record<Tone, string> = {
  violet: 'bg-violet-500/10 text-violet-500',
  emerald: 'bg-emerald-500/10 text-emerald-500',
  rose: 'bg-rose-500/10 text-rose-500',
  amber: 'bg-amber-500/10 text-amber-500'
};
